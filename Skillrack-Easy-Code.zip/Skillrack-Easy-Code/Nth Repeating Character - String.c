A string S is passed as the input to the program. 
The program must print the Nth repeating character C in the string S.
The repeating characters are considered in their order of occurrence from the beginning of the string S. 
If no such Nth repeating character is present the program must print -1 as the output
Example Input/Output 1:
Input:
abcdaeaedbapple
3

Output:
d

Explanation:
a is the first repeating character.
b is the second repeating character.
c is not repeating and hence not considered.
d is the third repeating character and as here N=3, d is printed as the output.

Example Input/Output 2:
Input:
desktoppublishing
3

Output:
i

