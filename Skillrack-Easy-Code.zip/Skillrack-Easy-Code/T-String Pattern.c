#include&lt;stdio.h&gt;
#include &lt;stdlib.h&gt;

int main()
{
char s1[101],s2[101];
scanf(&quot;%s %s&quot;,s1,s2);
int i,l1=strlen(s1),l2=strlen(s2),r,c,p;
printf(&quot;%s\n&quot;,s1);
